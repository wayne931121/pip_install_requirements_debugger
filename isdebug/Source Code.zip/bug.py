#This script will be error after some package install
#We need to find that package is what
#This script use by sdebug.py 
import torch
print("No Bug.")